#!/bin/bash
$prep
$special
$main
$finalize
