/*
  * $Id: Life.h,v 1.6 2012/07/13 19:00:18 charliep Exp $
  * This file is part of BCCD, an open-source live CD for computational science
  * education.
  * 
  * Copyright (C) 2010 Andrew Fitz Gibbon, Paul Gray, Kevin Hunter, Dave 
  *   Joiner, Sam Leeman-Munk, Tom Murphy, Charlie Peck, Skylar Thompson, & Aaron Weeden 

  * 
  * This program is free software: you can redistribute it and/or modify
  * it under the terms of the GNU General Public License as published by
  * the Free Software Foundation, either version 3 of the License, or
  * (at your option) any later version.
  * 
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  * GNU General Public License for more details.
  * 
  * You should have received a copy of the GNU General Public License
  * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*******************************************
MPI Life 1.0
Copyright 2002, David Joiner and
  The Shodor Education Foundation, Inc.
Updated 2010, Andrew Fitz Gibbon and
  The Shodor Education Foundation, Inc.
Updated 2013, Ivana Marincic and Yu Zhao,
  Macalester College
*******************************************/

#ifndef BCCD_LIFE_H
#define BCCD_LIFE_H

#ifdef _MPI
#include <mpi.h>
#endif

#include "XLife.h"    // For display routines
#include "Defaults.h" // For Life's constants

#ifdef __CUDACC__
#include "CUDA.cu"
#endif

#ifdef STAT_KIT
#include "../StatKit/petakit/pkit.h"    // For PetaKit output
#endif

#include <time.h>     // For seeding random
#include <stdlib.h>   // For malloc et al.
#include <stdbool.h>  // For true/false
#include <getopt.h>   // For argument processing
#include <stdio.h>    // For file i/o
#include <string.h>   // For strcmp()
#include <unistd.h>   // For usleep()

int        init (struct life_t * life, struct cuda_t *cuda, int * c, char *** v);
void       eval_rules (struct life_t * life, struct cuda_t *cuda);
void       copy_bounds (struct life_t * life);
void       update_grid (struct life_t * life);
void          throttle (struct life_t * life);
void    allocate_grids (struct life_t * life);
void        init_grids (struct life_t * life);
void        write_grid (struct life_t * life);
void        free_grids (struct life_t * life);
double     rand_double ();
void    randomize_grid (struct life_t * life, double prob);
void       seed_random (int rank);
void           cleanup (struct life_t * life);
void        parse_args (struct life_t * life, int argc, char ** argv);
void             usage ();
char*          version ();
void    handle_columns (struct life_t * life);
void       write_stats (struct life_t * life, float total_time);
float     get_max_time (struct life_t *life, float total_time);

/*
    init_env()
        Initialize runtime environment.
*/
int init (struct life_t * life, struct cuda_t *cuda, int * c, char *** v) 
{
    int argc          = *c;
    char ** argv      = *v;
    life->rank        = 0;
    life->size        = 1;
    life->throttle    = DEFAULT_THROTTLE;
    life->ncols       = DEFAULT_SIZE;
    life->nrows       = DEFAULT_SIZE;
    life->generations = DEFAULT_GENS;
    life->do_display  = DEFAULT_DISP;
    life->infile      = NULL;
    life->outfile     = NULL;


    life->statsfile   = NULL;   //new
    life->offset      = 0;      //new
    life->remainder   = 0;      //new

    #ifdef _MPI
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &life->rank);
    MPI_Comm_size(MPI_COMM_WORLD, &life->size);
    #endif

    #ifdef _OPENMP
    omp_set_num_threads(omp_get_num_procs());
    #endif

    seed_random(life->rank);

    parse_args(life, argc, argv);

    handle_columns(life); //takes care of splitting columns among processes

    init_grids(life);

    if (life->do_display) {
        setWindowDimensions(life);
        setupWindow(life);
        moveWindow(life);
    }

    // if use CUDA, do cuda_init()
    #if defined(__CUDACC__) || defined(MPICUDA)
    cuda_init(life, cuda);
    #endif

    return(0);
}

/*
    eval_rules()
        Evaluate the rules of Life for each cell; count
        neighbors and update current state accordingly.
*/
void eval_rules (struct life_t *life, struct cuda_t *cuda) 
{
    int ncols = life->ncols;
    int nrows = life->nrows;

    int i,j,k,l,neighbors;
    int * grid      = life->grid;
    int * next_grid = life->next_grid;

    #ifdef _OPENMP
    #pragma omp parallel for private(neighbors,j,k,l)
    #endif

    for (i = 1; i <= ncols; i++) {
        for (j = 1; j <= nrows; j++) {
            neighbors = 0;

            // count neighbors
            for (k = i-1; k <= i+1; k++) {
                for (l = j-1; l <= j+1; l++) {
                    if (!(k == i && l == j) && grid[k*(nrows+2)+l] != DEAD)
                        neighbors++;
                }
            }

            // update state
            if (neighbors < LOWER_THRESH || neighbors > UPPER_THRESH)
                next_grid[i*(nrows+2)+j] = DEAD;
            else if (grid[i*(nrows+2)+j] != DEAD || neighbors == SPAWN_THRESH)
                next_grid[i*(nrows+2)+j] = grid[i*(nrows+2)+j]+1;
        }
    }
}

/*
    copy_bounds()
        Copies sides, top, and bottom to their respective locations.
        All boundaries are considered periodic.

        In the MPI model, processes are aligned side-by-side.
        Left and right sides are sent to neighboring processes.
        Top and bottom are copied from the process's own grid.
*/
void copy_bounds (struct life_t * life) 
{
    int i;

    #ifdef _MPI
    int rank  = life->rank;
    #endif

    int size  = life->size;
    int ncols = life->ncols;
    int nrows = life->nrows;
    int *grid = life->grid;

    #ifdef _MPI
    MPI_Status status;
    int left_rank  = (rank-1+size) % size;
    int right_rank = (rank+1) % size;

    enum TAGS {
        TOLEFT,
        TORIGHT
    };

    // Some MPIs deadlock if a single process tries to communicate
    // with itself
    if (size != 1) {
        // copy sides to neighboring processes
        MPI_Sendrecv(&grid[nrows+2], nrows+2, MPI_INT, left_rank, TOLEFT,
            &grid[(nrows+2)*(ncols+1)], nrows+2, MPI_INT, right_rank, TOLEFT,
            MPI_COMM_WORLD, &status);

        MPI_Sendrecv(&grid[(nrows+2)*(ncols)], nrows+2, MPI_INT, right_rank,
            TORIGHT, &grid[0], nrows+2, MPI_INT, left_rank,
            TORIGHT, MPI_COMM_WORLD, &status);
    }
    #endif

    // Copy sides locally to maintain periodic boundaries
    // when there's only one process
    if (size == 1) {
        for (i = 0; i < nrows+2; i++) {
            grid[i] = grid[(nrows+2)*(ncols)+i];
            grid[(nrows+2)*(ncols+1)+i] = grid[(nrows+2)+i];
        }
    }

    // copy top and bottom
    for (i = 0; i < ncols+2; i++) {
        grid[(nrows+2)*i] = grid[(nrows+2)*i+(nrows)]; // top ghost row
        grid[(nrows+2)*i+(nrows+1)] = grid[(nrows+2)*i+1]; // bottom ghost row
    }
}

/*
    update_grid()
        Copies temporary values from next_grid into grid.
*/
void update_grid (struct life_t * life) 
{
    int i,j;
    int ncols = life->ncols;
    int nrows = life->nrows;
    int * grid      = life->grid;
    int * next_grid = life->next_grid;
    
    #ifdef _OPENMP
    #pragma omp parallel for private(j)
    #endif
    for (i = 0; i < ncols+2; i++)
        for (j = 0; j < nrows+2; j++)
            grid[i*(nrows+2)+j] = next_grid[i*(nrows+2)+j];
}

/*
    throttle()
        Slows down the simulation to make X display easier to watch.
        Has no effect when run with --no-display.
*/
void throttle (struct life_t * life) 
{
    // unsigned int delay;
    int t = life->throttle;

    if (life->do_display && t != -1) {
        //delay = 1000000 * 1/t;
        //usleep(delay);
        usleep(t);
    }
}

/*
    allocate_grids()
        Allocates memory for a 2D array of integers.
*/
void allocate_grids (struct life_t * life) 
{
    
    int ncols = life->ncols;
    int nrows = life->nrows;

    life->grid      = (int *) malloc(sizeof(int) * (ncols+2) * (nrows+2));
    life->next_grid = (int *) malloc(sizeof(int) * (ncols+2) * (nrows+2));
}

/*
    init_grids()
        Initialize cells based on input file, otherwise all cells
        are DEAD.
*/
void init_grids (struct life_t * life) 
{
    FILE * fd;
    int i,j;

    if (life->infile != NULL) {
        if ((fd = fopen(life->infile, "r")) == NULL) {
            perror("Failed to open file for input");
            exit(EXIT_FAILURE);
        }

        if (fscanf(fd, "%d %d\n", &life->ncols, &life->nrows) == EOF) {
            printf("File must at least define grid dimensions!\nExiting.\n");
            exit(EXIT_FAILURE);
        }
    }

    /* do not move to the front, values depend on input file */
    int nrows = life->nrows;
    int ncols = life->ncols;

    allocate_grids(life);

    for (i = 0; i < ncols+2; i++) {
        for (j = 0; j < nrows+2; j++) {
            life->grid[i*(nrows+2)+j]      = DEAD;
            life->next_grid[i*(nrows+2)+j] = DEAD;
        }
    }

    if (life->infile != NULL) {
        while (fscanf(fd, "%d %d\n", &i, &j) != EOF) {
            life->grid[i*(nrows+2)+j]        = ALIVE;
            life->next_grid[i*(nrows+2)+j]   = ALIVE;
        }
        fclose(fd);
    } else {
        randomize_grid(life, INIT_PROB);
    }
}

/*
    write_grid()
        Dumps the current state of life.grid to life.outfile.
        Only outputs the coordinates of !DEAD cells.
*/
void write_grid (struct life_t * life) 
{
    FILE * fd;
    int i,j;
    int ncols   = life->ncols;
    int nrows   = life->nrows;
    int * grid  = life->grid;

    if (life->outfile != NULL) {
        if ((fd = fopen(life->outfile, "w")) == NULL) {
            perror("Failed to open file for output");
            exit(EXIT_FAILURE);
        }

        fprintf(fd, "%d %d\n", ncols, nrows);

        for (i = 1; i <= ncols; i++) {
            for (j = 1; j <= nrows; j++) {
                if (grid[i*(nrows+2)+j] != DEAD)
                    fprintf(fd, "%d %d\n", i, j);
            }
        }

        fclose(fd);
    }
}

/*
    free_grids()
        Frees memory used by an array that was allocated 
        with allocate_grids().
*/
void free_grids (struct life_t * life) 
{

    free(life->grid);
    free(life->next_grid);
}

/*
    rand_double()
        Generate a random double between 0 and 1.
*/
double rand_double() 
{
    return (double)random()/(double)RAND_MAX;
}

/*
    randomize_grid()
        Initialize a Life grid. Each cell has a [prob] chance
        of starting alive.
*/
void randomize_grid (struct life_t * life, double prob) 
{
    int i,j;
    int ncols = life->ncols;
    int nrows = life->nrows;

    for (i = 1; i <= ncols; i++) {
        for (j = 1; j <= nrows; j++) {
            if (rand_double() < prob)
                life->grid[i*(nrows+2)+j] = ALIVE;
        }
    }   
}

/*
    seed_random()
        Seed the random number generator based on the
        process's rank and time. Multiplier is arbitrary.
*/
void seed_random (int rank) {
    srandom(time(NULL) + 100*rank);
}

/*
    cleanup()
        Prepare process for a clean termination.
*/
void cleanup (struct life_t * life) 
{
    write_grid(life);
    free_grids(life);

    if (life->do_display)
        free_video(life);

    #ifdef _MPI
    MPI_Finalize();
    #endif
}

/*
    usage()
        Describes Life's command line option
*/
void usage () 
{
    printf("\nUsage: Life [options]\n");
    printf("  -c|--columns number   Number of columns in grid. Default: %d\n", DEFAULT_SIZE);
    printf("  -r|--rows number      Number of rows in grid. Default: %d\n", DEFAULT_SIZE);
    printf("  -g|--gens number      Number of generations to run. Default: %d\n", DEFAULT_GENS);
    printf("  -i|--input filename   Input file. See README for format. Default: none.\n");
    printf("  -o|--output filename  Output file. Default: none.\n");
    printf("  -s|--output-stats filename   Stats output file. Default: none.\n");
    printf("  -h|--help             This help page.\n");
    printf("  -t[N]|--throttle[=N]  Throttle display to N generations/second. Default: %d\n",
        DEFAULT_THROTTLE);
    printf("  -x|--display          Use a graphical display.\n");
    printf("  --no-display          Do not use a graphical display.\n"); 
    printf("     Default: %s\n",
        (DEFAULT_DISP ? "do display" : "no display"));
    printf("\nSee README for more information.\n\n");

    exit(EXIT_FAILURE);
}

/*
    parse_args()
        Make command line arguments useful
*/
void parse_args (struct life_t * life, int argc, char ** argv) 
{
    int opt       = 0;
    int opt_index = 0;

    for (;;) {
        opt = getopt_long(argc, argv, opts, long_opts, &opt_index);

        if (opt == -1) break;

        switch (opt) {
            case 0:
                if (strcmp("no-display", long_opts[opt_index].name) == 0)
                    life->do_display = false;
                break;
            case 'c':
                life->ncols = strtol(optarg, (char**) NULL, 10);
                break;
            case 'r':
                life->nrows = strtol(optarg, (char**) NULL, 10);
                break;
            case 'g':
                life->generations = strtol(optarg, (char**) NULL, 10);
                break;
            case 'x':
                life->do_display = true;
                break;
            case 'i':
                life->infile = optarg;
                break;
            case 'o':
                life->outfile = optarg;
                break;
            case 's':
                life->statsfile = optarg;
                break;
            case 't':
                life->throttle = strtol(optarg, (char**) NULL, 10);
                break;
            case 'h':
            case '?':
                usage();
                break;

            default:
                break;
        }
    }

    // Backwards compatible argument parsing
    if (optind == 1) {
        if (argc > 1)
            life->nrows       = strtol(argv[1], (char**) NULL, 10);
        if (argc > 2)
            life->ncols       = strtol(argv[2], (char**) NULL, 10);
        if (argc > 3)
            life->generations = strtol(argv[3], (char**) NULL, 10);
        if (argc > 4)
            // 0 interpreted as false, all other values true
            life->do_display  = strtol(argv[4], (char**) NULL, 10);
    }
}

/*
    version() 
        return the version compiled
*/
char* version()
{
    char* version = "Serial";

    #if defined(_OPENMP) && !defined(_MPI)
        version = "OpenMP only";
    #endif

    #if defined(_MPI) && !defined(_OPENMP) && !defined(MPICUDA)
        version = "MPI only";
    #endif

    #ifdef __CUDACC__
        version = "CUDA only";
    #endif

    #if defined(_OPENMP) && defined(_MPI)
        version = "MPI+OpenMP Hybrid";
    #endif

    #ifdef MPICUDA
        version = "MPI+CUDA Hybrid";
    #endif

    return version;
}

/*
    get_max_time()
        when using MPI, gather time used by all processes and return
        the longest one.   
*/
float get_max_time(struct life_t *life, float total_time) 
{
    #ifdef _MPI
        MPI_Status stat;
        // except process 0, all processes send time to other processes
        if(life->rank > 0) {
            float send_time;
            send_time = total_time;
            MPI_Send(&send_time,1,MPI_FLOAT,0,3,MPI_COMM_WORLD);
        }
        // process 0 select the maximum time
        if(life->rank == 0) {
            float max = total_time;
            float received_time=-1.0;
            int i;
            for(i =1;i<life->size;i++){
                MPI_Recv(&received_time, 1, MPI_FLOAT, i, 3, 
                    MPI_COMM_WORLD, &stat);
                if(received_time>=max) 
                    max = received_time;
            }
            return max;
        }
    #endif
    return 0;
}

/*
    write_stats()
        Writes and appends to a cvs file the following 
        information (tab separated):
        compiled version, rows, columns, generations, 
        problem_size, number_of_processes, total_time
*/
void write_stats(struct life_t * life, float total_time) 
{
    FILE * fd;

    if(life->statsfile != NULL) {
        if((fd = fopen(life->statsfile,"a+")) == NULL) {
            perror("Failed to open file for stats output");
            exit(EXIT_FAILURE);
        }
        #ifdef _MPI
        if(life->remainder!=0)
        { 
            if(life->offset ==0)
            {
                fprintf(fd, "%s\t%d\t%d\t%d\t%d\t%d\t%f\n", 
                    version(), life->nrows, 
                    ((life->ncols-1)*life->size)+life->remainder,
                    life->generations, life->nrows*life->ncols*life->size, 
                    life->size, total_time);
            }else{
                fprintf(fd, "%s\t%d\t%d\t%d\t%d\t%d\t%f\n", 
                    version(), life->nrows, 
                    (life->ncols*life->size)+life->remainder,
                    life->generations, life->nrows*life->ncols*life->size,
                    life->size, total_time);
            }
        }else{
            fprintf(fd, "%s\t%d\t%d\t%d\t%d\t%d\t%f\n", 
                version(), life->ncols*life->size, life->nrows, 
                life->generations, life->nrows*life->ncols*life->size, 
                life->size, total_time);
        }
        #else
        fprintf(fd, "%s\t%d\t%d\t%d\t%d\t%d\t%f\n", 
            version(), life->ncols, life->nrows, life->generations, 
            life->ncols*life->nrows, 1, total_time);

        #endif

        fclose(fd);
    }
}

/* 
    handle_columns()
        Check whether the column size specified in the command 
        line is divisible by the number of processes. Update the 
        remainder from life_t struct which will be needed later 
        for X windowing. If remainder is not 0, then distribute 
        the remainder among the processes. Offset specifies by 
        how much must an X window be moved to align with the 
        previous window. 
*/
void handle_columns(struct life_t * life) 
{
    int rank = life->rank;
    int size = life->size;
    int remainder;

    remainder = life->ncols % size;
    life->remainder = remainder;
    if(remainder !=0) 
    { 
        // if the number of columns is not divisible 
        // by the number of processes
        if(rank < remainder)
        {
            life->ncols= (life->ncols / size) + 1;
            //offset important for moving windows
            life->offset = 0; 
        } 
        else {
            life->ncols = life->ncols / size;
            // this is derived based on how the X window width is calculated 
            // there is an offset because the X window sizes are different
            life->offset = (DEFAULT_WIDTH/life->nrows)*(remainder); 
        }
    }
    //every process gets an equal amount of columns
    else{
        life->ncols = life->ncols / size;
    } 
}

#endif
