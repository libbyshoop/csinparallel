/*
  * $Id: Life.c,v 1.4 2012/06/27 16:26:57 charliep Exp $
  * This file is part of BCCD, an open-source live CD for computational science
  * education.
  * 
  * Copyright (C) 2010 Andrew Fitz Gibbon, Paul Gray, Kevin Hunter, Dave 
  *   Joiner, Sam Leeman-Munk, Tom Murphy, Charlie Peck, Skylar Thompson, & Aaron Weeden 

  * 
  * This program is free software: you can redistribute it and/or modify
  * it under the terms of the GNU General Public License as published by
  * the Free Software Foundation, either version 3 of the License, or
  * (at your option) any later version.
  * 
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  * GNU General Public License for more details.
  * 
  * You should have received a copy of the GNU General Public License
  * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


/*******************************************
MPI Life 1.0
Copyright 2002, David Joiner and
  The Shodor Education Foundation, Inc.
Updated 2010, Andrew Fitz Gibbon and
  The Shodor Education Foundation, Inc.
Updated 2013, Ivana Marincic and Yu Zhao,
  Macalester College

A C implementation of Conway's Game of Life.

To run:
./Life [Rows] [Columns] [Generations] [Display]

See the README included in this directory for
more detailed information.
*******************************************/

#include "Life.h"
#include "Defaults.h" // For Life's constants

int main(int argc, char ** argv) {

	int count;
	struct life_t life;
	// if not using CUDA, initialize a empty struct
	struct cuda_t cuda;
	
	#ifdef STAT_KIT
		double total_time;

		// if not using CUDA, declare start_time and end_time
		#ifndef CUDA_STAT
			double start_time, end_time;
		#endif

		// if using MPI, declare t_time 
		#ifdef _MPI
			float t_time;
		#endif
	#endif

	init(&life, &cuda, &argc, &argv);

	#ifdef STAT_KIT
		// if not using CUDA, start CPU timer
		#ifndef CUDA_STAT
			start_time = startTimer_usec();
		#endif
	#endif

	for (count = 0; count < life.generations; count++) 
	{
		if (life.do_display)
			do_draw(&life);

		copy_bounds(&life);

		#if defined(__CUDACC__) || defined(MPICUDA)
		/*************** for versions that IS using CUDA ***************/
			kernel_function(&life, &cuda);
		/***************************************************************/
		#else
		/************* for versions that is NOT using CUDA *************/
			eval_rules(&life, &cuda);
		/***************************************************************/
		#endif

		update_grid(&life);

		throttle(&life);
	}

	// this code gets timing stats for CUDA
	#if defined(__CUDACC__) || defined(MPICUDA)
		cuda_finish(&life, &cuda);
	#endif

	#ifdef STAT_KIT

		#ifdef CUDA_STAT
			total_time = (double) cuda.elapsedTime * 1000;
		#else
			end_time = endTimer_usec();
			total_time = end_time-start_time;
		#endif

		#ifdef _MPI
			t_time = get_max_time(&life, total_time);
			if(life.rank == 0) write_stats(&life, t_time);
		#else
			write_stats(&life, total_time);
		#endif

	#endif

	cleanup(&life);

	// for debug purpose, can return version
	// printf("This is the %s version \n", version());

	#ifdef STAT_KIT
		// transform total_time from microseconds to seconds 
		total_time /= 1000000;
		printStats(total_time,"Life",life.size,version(),life.ncols*life.nrows, 
			"1.3", 0, 3, "iCOLUMNS", (long long int) life.ncols, "iROWS", 
			(long long int)life.nrows, "iGENERATIONS", (long long int)life.generations);
	#endif

	exit(EXIT_SUCCESS);
}
