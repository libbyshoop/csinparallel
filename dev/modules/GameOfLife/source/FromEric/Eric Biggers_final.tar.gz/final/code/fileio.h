

unsigned char* read_file(const char* filename, unsigned* width_ret, unsigned* height_ret,
				unsigned width_override, unsigned height_override);
