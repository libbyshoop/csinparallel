#include "raw_page.hpp"

raw_page::raw_page(void)
{
    m_curl = curl_easy_init();
}

raw_page::raw_page(const raw_page & other)
{
    m_curl = 0;
    m_html = other.m_html;
}

raw_page::~raw_page(void)
{
    if (m_curl)
        curl_easy_cleanup(m_curl);
}

raw_page & raw_page::operator=(const raw_page & other)
{
    if (this != &other)
    {
        if (m_curl)
            curl_easy_cleanup(m_curl);
        m_curl = 0;
        m_html = other.m_html;
    }
    
    return *this;
}

bool raw_page::fetch(const char * url)
{
    if (!m_curl) return false;
    curl_easy_setopt(m_curl, CURLOPT_URL, url);
	curl_easy_setopt(m_curl, CURLOPT_WRITEDATA, this);
	curl_easy_setopt(m_curl, CURLOPT_WRITEFUNCTION, 
		&raw_page::write_data);
			
	CURLcode res;
	res = curl_easy_perform(m_curl);
	return true;
}

const std::string & raw_page::get_html(void) const
{
    return m_html;
}

size_t raw_page::write_data(void * data, size_t sz, size_t nmemb, void * p)
{
	return static_cast<raw_page *>(p)->write_data_obj(data, sz, nmemb);
}

size_t raw_page::write_data_obj(void * data, size_t sz, size_t nmemb)
{
	m_html.append(static_cast<char *>(data), sz * nmemb);
	return sz * nmemb;
}
