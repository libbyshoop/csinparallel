#include "raw_page.hpp"
#include "page.hpp"
#include "spider.hpp"
#include <iostream>
#include <string>
#include <sstream>

using std::cout;
using std::endl;
using std::string;
using std::stringstream;

void usage(void)
{
    cout << "spider max url" << endl << "\tmax = Max url count." << endl
     << "\turl = Base url for crawling." << endl;
}

int main(int argc, char ** argv)
{
    if (argc < 3 || argc > 3)
    {
        usage();
        return 0;
    }
    
    size_t max = 1;
    string s(argv[2]);
    string interp(argv[1]);
    stringstream ss(interp);
    ss >> max;
    
    spider crawler(max);
    crawler.crawl(s);
    crawler.output();
    
    return 0;
}
