#include "raw_page.hpp"
#include "page.hpp"
#include "spider.hpp"
#include <algorithm>
#include <iostream>

spider::spider(void)
{
    m_maxUrls = 1;
}

spider::spider(size_t urls)
{
    m_maxUrls = urls;
}

spider::spider(const spider & other)
{
    m_maxUrls = other.m_maxUrls;
}

spider & spider::operator=(const spider & other)
{
    m_maxUrls = other.m_maxUrls;
    return *this;
}

spider::~spider(void)
{
}

void spider::crawl(const char * startURL)
{
    std::string s(startURL);
    this->crawl(s);
}

void spider::crawl(const std::string & startURL)
{
    while (!m_work.empty()) m_work.pop();
    m_finished.clear();
    m_pages.clear();
    
    m_work.push(startURL);
    size_t processed = 0;
    
    while (processed < m_maxUrls && !m_work.empty())
    {
        std::string url = m_work.front(); m_work.pop();
        raw_page data;
        
       if (already_finished(url)) continue;

       /* INSERT CODE HERE
	  The line above indicates that this  url  has not yet been processed.
	  Your code should fetch the data for this  url , process that 
	  data, add this  url  to the finished queue, and update the counter 
	  named  processed .  */

    }
}

void spider::process(const std::string & url, const std::string & html)
{
    std::string baseUrl(getBaseUrl(url));
    page p; 
    p.scan(baseUrl, url, html);
    
    for (size_t i = 0; i < p.get_urls()->size(); ++i)
    {
      /* INSERT CODE HERE
	 The  page  object  p  now includes a list of url's that appear in 
	 links within this page.  For each such url with index  i , if that 
	 url is not an image, add it to the work queue. */
    }
    
    m_pages.push_back(p);
}

bool spider::is_image(const std::string & url) const
{
    return false;
}

bool spider::already_finished(const std::string &url) 
{
    std::vector<std::string>::iterator it;
    it = std::find(m_finished.begin(), m_finished.end(), url);
    return it != m_finished.end();
}

std::string spider::getBaseUrl(const std::string &url) 
{
    std::string baseUrl(url);
    std::string alt = baseUrl.substr(0, baseUrl.find_last_of('/'));
    if (alt.compare("http:/") != 0 && alt.compare("ftp:/") != 0)
        baseUrl = alt;
    
    if (baseUrl.size() > 0 && baseUrl.at(baseUrl.size() - 1) != '/')
        baseUrl.append("/");
    return baseUrl;
}

void spider::output(void)
{
    using std::cout;
    using std::endl;
    
    cout << "Processed " << m_pages.size() << " pages." << endl;
    for (size_t i = 0; i < m_pages.size(); ++i)
    {
        cout << "\tPage [" << i << "]: " << m_pages[i].get_url() << " with "
            << m_pages[i].get_urlCount() << " urls." << endl;
    }
}
