#ifndef _RAW_PAGE_HPP_
#define _RAW_PAGE_HPP_

#include <curl/curl.h>
#include <string>

class raw_page
{
private:
    std::string m_html;
    CURL * m_curl;

private:
    static size_t write_data(void * data, size_t sz, size_t nmemb, void * p);
	size_t write_data_obj(void * data, size_t sz, size_t nmemb);

public:
    raw_page(void);
    raw_page(const raw_page &);
    ~raw_page(void);
    
    raw_page & operator=(const raw_page &);
    
    bool fetch(const char *);
    
    const std::string & get_html(void) const;
};

#endif
