#ifndef _PAGE_HPP_
#define _PAGE_HPP_

#include <string>
#include <vector>

class page
{
private:
    std::vector<std::string> m_urls;
    std::string m_url;
    
public:
    page(void);
    ~page(void);
    
    void scan(const std::string & baseUrl, const std::string & url, const std::string & html);
    
    std::vector<std::string> * get_urls(void);
    size_t get_urlCount(void) const;
    std::string get_url(void) const;
};

#endif
