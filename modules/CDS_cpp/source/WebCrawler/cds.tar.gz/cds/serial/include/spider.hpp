#ifndef _SPIDER_HPP_
#define _SPIDER_HPP_

#include "raw_page.hpp"
#include <queue>
#include <vector>
#include <string>

class spider
{
private:
    std::queue<std::string> m_work;
    std::vector<std::string> m_finished;
    std::vector<page> m_pages;
    size_t m_maxUrls;
    
    spider(const spider &);
    spider & operator=(const spider &);

public:
    spider(void);
    spider(size_t);
    ~spider(void);
    
    void crawl(const char *);
    void crawl(const std::string &);
    void output(void);

private:
    void process(const std::string &, const std::string &);
    bool is_image(const std::string &) const;
    bool already_finished(const std::string &url);
    std::string getBaseUrl(const std::string&);
};

#endif
