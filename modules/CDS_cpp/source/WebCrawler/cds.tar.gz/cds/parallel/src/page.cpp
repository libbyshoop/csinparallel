#include "page.hpp"
#include <boost/regex.hpp>
#include <iostream>

using std::cout;
using std::endl;

page::page(void)
{
}

page::~page(void)
{
}

void page::scan(const std::string & baseUrl, const std::string & url, const std::string & html)
{
    //boost::regex re("<a\\s+href=\"([\\-:\\w\\d\\.\\/]+)\">");
    boost::regex re("<a.*?href=\"(.*?)\".*?>");
    boost::smatch matches;
    
    m_url = url;
    m_urls.clear();
    
    std::string::const_iterator begin = html.begin();
    
    while (boost::regex_search(begin, html.end(), matches, re))
    {
        std::string m(matches[1].first, matches[1].second);
        if (m.empty()) { begin = matches[1].second; continue; }
        
        if (m.find("http://") == m.npos &&
            m.find("ftp://") == m.npos)
        {
            std::string build(baseUrl);
            if (m.at(0) == '.')
                m = m.substr(1);
            if (m.at(0) == '/')
                m = m.substr(1);
            build.append(m);
            m = build;
        }
            
        m_urls.push_back(m);
        begin = matches[1].second;
    }
}

std::vector<std::string> * page::get_urls(void)
{
    return &m_urls;
}

size_t page::get_urlCount(void) const
{
    return m_urls.size();
}

std::string page::get_url(void) const
{
    return m_url;
}
