#include "raw_page.hpp"
#include "page.hpp"
#include "spider.hpp"
#include <boost/bind.hpp>
#include <boost/thread/thread.hpp>
#include <algorithm>
#include <iostream>
using namespace std;

spider::spider(void)
{
    m_maxUrls = 1;
}

spider::spider(size_t urls, size_t threadCount)
{
    m_maxUrls = urls;
    m_threadCount = threadCount;
}

spider::spider(const spider & other)
{
    m_maxUrls = other.m_maxUrls;
    m_threadCount = other.m_threadCount;
}

spider & spider::operator=(const spider & other)
{
    m_maxUrls = other.m_maxUrls;
    m_threadCount = other.m_threadCount;
    return *this;
}

spider::~spider(void)
{
}

void spider::crawl(const char * startURL)
{
    std::string s(startURL);
    this->crawl(s);
}

void spider::crawl(const std::string & startURL)
{
    m_work.clear();
    m_finished.clear();
    m_pages.clear();
    
    m_work.push(startURL);
    m_processed.reset();
    
    // Seed the queue with the initial page.
    // This will help overcome the problem where only one thread ends up
    // doing work.
    /* work_once(); */
    
    boost::thread ** threads = new boost::thread *[m_threadCount];
    for (size_t i = 0; i < m_threadCount; ++i)
    {
        threads[i] = new boost::thread(boost::bind(&spider::work, this, i));
    }
    
    for (size_t i = 0; i < m_threadCount; ++i)
    {
        threads[i]->join();
    }
    
    if (threads != 0) {
      for (size_t i = 0; i < m_threadCount; ++i)
	delete threads[i];
      delete [] threads;
    }
}

void spider::work(int id)
{
    int count = 0;  // number of URLs processed by this thread
    while (m_processed.value() < m_maxUrls && !m_work.empty())
    {
        // tbb concurrent_queue being used here
        // Note: we may have a case where the work is not empty, we enter, and
        // then it becomes empty while we are here. Using try_pop will help us
        // recover from this and try again.
        std::string url;
        if (!m_work.try_pop(url)) continue;
        
        // we use this to load the page
        raw_page data;
        
        if (already_finished(url)) continue;
        
       /* INSERT CODE HERE
	  The line above indicates that this  url  has not yet been processed.
	  Your code should fetch the data for this  url , process that 
	  data, add this  url  to the finished queue, and update the counter 
	  named  processed .  */

	count++;
    }
    cout << "Thread " << id << " finished after processing " 
	 << count << " URLs" << endl;
}

void spider::work_once(void)
{
    // tbb concurrent_queue being used here
    std::string url;
    if (!m_work.try_pop(url)) return;
        
    // we use this to load the page
    raw_page data;
       
    m_finished.push_back(url);
    if (!data.fetch(url.c_str()))
    {
        m_processed.increment();
        return;
    }
        
    this->process(url, data.get_html());
    m_processed.increment();
}

void spider::process(const std::string & url, const std::string & html)
{
    std::string baseUrl(getBaseUrl(url));
    page p; 
    p.scan(baseUrl, url, html);
    
    for (size_t i = 0; i < p.get_urls()->size(); ++i)
    {
      /* INSERT CODE HERE
	 The  page  object  p  now includes a list of url's that appear in 
	 links within this page.  For each such url with index  i , if that 
	 url is not an image, add it to the work queue. */
    }
    
    m_pages.push_back(p);
}

bool spider::is_image(const std::string & url) const
{
    return false;
}

bool spider::already_finished(const std::string &url) 
{
    tbb::concurrent_vector<std::string>::iterator it;
    tbb::concurrent_vector<std::string>::iterator it_end = m_finished.end();
    it = std::find(m_finished.begin(), m_finished.end(), url);
    return it != it_end;
}

std::string spider::getBaseUrl(const std::string &url) 
{
    std::string baseUrl(url);
    std::string alt = baseUrl.substr(0, baseUrl.find_last_of('/'));
    if (alt.compare("http:/") != 0 && alt.compare("ftp:/") != 0)
        baseUrl = alt;
    
    if (baseUrl.size() > 0 && baseUrl.at(baseUrl.size() - 1) != '/')
        baseUrl.append("/");
    return baseUrl;
}

void spider::output(void)
{
    using std::cout;
    using std::endl;
    
    cout << "Processed " << m_pages.size() << " pages." << endl;
    for (size_t i = 0; i < m_pages.size(); ++i)
    {
        cout << "\tPage [" << i << "]: " << m_pages[i].get_url() << " with "
            << m_pages[i].get_urlCount() << " urls." << endl;
    }
}
