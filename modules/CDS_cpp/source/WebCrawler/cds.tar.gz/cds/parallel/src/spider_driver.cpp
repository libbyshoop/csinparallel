#include "raw_page.hpp"
#include "page.hpp"
#include "spider.hpp"
#include <iostream>
#include <string>
#include <sstream>

using std::cout;
using std::endl;
using std::string;
using std::stringstream;

void usage(void)
{
    cout << "spider max threads url" << endl << "\tmax = Max url count." << endl
        << "\tthreads = Number of threads to use." << endl
        << "\turl = Base url for crawling." << endl;
}

int main(int argc, char ** argv)
{
    if (argc < 4 || argc > 4)
    {
        usage();
        return 0;
    }
    
    size_t max = 1;
    size_t threadCount = 2;

    string s(argv[3]);
    string interp(argv[1]);
    stringstream ss(interp);
    ss >> max;
    --max;
    string tct(argv[2]);
    stringstream ss2(tct);
    ss2 >> threadCount;
    
    spider crawler(max, threadCount);
    crawler.crawl(s);
    crawler.output();
    
    return 0;
}
