#ifndef _ATOMIC_COUNTER_HPP_
#define _ATOMIC_COUNTER_HPP_

#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>

class atomic_counter
{
private:
    size_t m_count;
    mutable boost::mutex m_incrementMutex;

public:
    atomic_counter(void)
    {
        m_count = 0;
    }
    
    atomic_counter(const atomic_counter & other)
    {
        m_count = other.m_count;
    }
    
    atomic_counter(size_t count)
    {
        m_count = count;
    }
    
    ~atomic_counter(void)
    {
    }
    
    atomic_counter & operator=(const atomic_counter & other)
    {
        if (this != &other)
        {
            boost::mutex::scoped_lock sl(m_incrementMutex);
            m_count = other.value();
        }
        return *this;
    }
    
    void increment(void)
    {
        boost::mutex::scoped_lock sl(m_incrementMutex);
        ++m_count;
    }
    
    size_t value(void) const
    {
        boost::mutex::scoped_lock sl(m_incrementMutex);
        size_t count = m_count;
        return count;
    }
    
    void reset(void)
    {
        boost::mutex::scoped_lock sl(m_incrementMutex);
        m_count = 0;
    }
};

#endif
