#ifndef _SPIDER_HPP_
#define _SPIDER_HPP_

#include "raw_page.hpp"
#include "atomic_counter.hpp"
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_vector.h>
#include <vector>
#include <string>

class spider
{
private:
    tbb::concurrent_queue<std::string> m_work;
    tbb::concurrent_vector<std::string> m_finished;
    tbb::concurrent_vector<page> m_pages;
    size_t m_maxUrls;
    atomic_counter m_processed;
    size_t m_threadCount;
    
    spider(const spider &);
    spider & operator=(const spider &);

public:
    spider(void);
    spider(size_t, size_t);
    ~spider(void);
    
    void crawl(const char *);
    void crawl(const std::string &);
    void output(void);

private:
    void work(int);
    void work_once(void);
    void process(const std::string &, const std::string &);
    bool is_image(const std::string &) const;
    bool already_finished(const std::string &url);
    std::string getBaseUrl(const std::string&);
};

#endif
