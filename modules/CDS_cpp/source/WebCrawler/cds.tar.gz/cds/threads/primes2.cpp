/* Example parallel program to compute primes */
#include <iostream>
#include <sstream>
using namespace std;
#include <cmath>
#include <boost/thread/thread.hpp>
#include <boost/bind.hpp>
using boost::thread;

#define MAX 10000000

bool prime[MAX];

void work(int min, int max) {
  for (int i = min;  i < max;  i++) {
    prime[i] = true;
    for (int j = 2;  j < sqrt(i);  j++)
      if (i%j == 0)
	prime[i] = false;
  }
}

int main (int argc, char **argv) {

  int threadct = 1;
  if (argc > 1) {
    stringstream sstr(argv[1]);
    sstr >> threadct;
  }

  prime[0] = prime[1] = false;

  thread * pool = new thread[threadct];

  int segsize = MAX/threadct;

  pool[0] = thread(boost::bind(work, 2, segsize));
		   
  for (int t = 1;  t < threadct-1;  t++) {
    pool[t] = thread(boost::bind(work, segsize*t, segsize*(t+1)));
  }
  
  if (threadct > 1)
    pool[threadct-1] = thread(boost::bind(work, segsize*(threadct-1), MAX));

  for (int t = 0;  t < threadct;  t++) 
    pool[t].join();

  delete [] pool;  pool = 0;

  int count = 0;
  for (int i = 0;  i < MAX;  i++)
    if (prime[i]) {
      count++;
      // cout << i << endl;
    }

  cout << count << " primes were found less than " << MAX << endl;
}
