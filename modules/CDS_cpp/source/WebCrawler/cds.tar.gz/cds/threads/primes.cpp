/* Example sequential program to compute primes */
#include <iostream>
using namespace std;
#include <cmath>

#define MAX 10000000

int main () {
  bool prime[MAX];

  prime[0] = prime[1] = false;
  for (int i = 2;  i < MAX;  i++) {
    prime[i] = true;
    for (int j = 2;  j < sqrt(i);  j++)
      if (i%j == 0)
	prime[i] = false;
  }
  int count = 0;
  for (int i = 0;  i < MAX;  i++)
    if (prime[i]) {
      count++;
      //cout << i << endl;
    }

  cout << count << " primes were found less than " << MAX << endl;
}
